const Product = require("../models/product.model");
const isEmpty = require('lodash.isempty');

// add product to store -- only admin can add product
exports.addProduct = (req, res, next) => {

    if (req.userData.role == 'admin') {

        if (isEmpty(req.body)) {
            return res.status(201).json({
                message: "Body content can't be empty",
                Status: "error",
                Title: "Missing Body",
            });
        }

        const productDetails = new Product({
            name: req.body.name,
            category: req.body.category,
            unit_price: req.body.unit_price,
            avl_quantity: req.body.avl_quantity,
            image: req.body.image,
            User_Id: req.userData.userId,
            deleted: "N"
        });

        productDetails.save()
            .then(result => {
                console.log("Product added successfully");

                res.status(200).json({
                    Status: "completed",
                    Title: "Add Product",
                    message: "Product added successfully",
                    ProductId: result._id
                });

            }).catch(err => {
                console.log(err);
                return res.status(500).json({
                    message: "Something went wrong.",
                    Status: "error",
                    Title: "Server Error",
                });
            })

    } else { // manager can't add product

        res.status(401).json({
            message: "You dont have correct privilege to perform this operation",
            Status: "error",
            Title: "Access Denied",
        })
    }
}

// get product details on the basis of product id - give productid in params
exports.getProduct = (req, res, next) => {
    Product.findById(req.params.id).then(productDetails => {
        if (productDetails) {

            res.status(200).json({
                message: "product details fetched successfully",
                Status: "completed",
                productInfo: productDetails,
            });
        } else {
            return res.status(500).json({
                message: "Invalid product Id",
                Status: "error",
                Title: "Invalid Id",
            });
        }
    }).catch(error => {
        return res.status(500).json({
            message: "Something went wrong.",
            Status: "error",
            Title: "Server Error",
        });
    });
}

// get products list
exports.productsList = (req, res, next) => {
    console.log("Fetching data")
    const postQuery = Product.find({
        User_Id: req.userData.userId,
        deleted: 'N'
    }).sort({
        Entered_Date: -1
    });
    let productsList = [];
    postQuery.
    then(documents => {

        for (let i = 0; i < documents.length; i++) {
            productsList.push({
                productId: documents[i].id,
                name: "" + documents[i].name,
                category: "" + documents[i].category,
                unit_price: "" + documents[i].unit_price,
                avl_quantity: "" + documents[i].avl_quantity,
                image: "" + documents[i].image,
                User_Id: "" + documents[i].User_Id
            });
        }

        res.status(200).json({
            message: "Products List fetched successfully.",
            TotalProducts: productsList.Count,
            Status: "completed",
            Products: productsList
        })

    }).catch(err => {
        console.log(err);
        return res.status(500).json({
            message: "Something went wrong.",
            Status: "error",
            Title: "Server Error",
        });
    })
}

// update product to store -- only admin can update product
exports.updateProduct = (req, res, next) => {

    if (req.userData.role == 'admin') {

        if (isEmpty(req.body)) {
            return res.status(201).json({
                message: "Body content can't be empty",
                Status: "error",
                Title: "Missing Body",
            });
        }
        if (isEmpty(req.params.id)) {
            return res.status(201).json({
                message: "Id is missing",
                Status: "error",
                Title: "Missing Id",
            });
        }
        const productDetails = new Product({
            name: req.body.name,
            category: req.body.category,
            unit_price: req.body.unit_price,
            avl_quantity: req.body.avl_quantity,
            image: req.body.image,
            User_Id: req.userData.userId,
            _id: req.params.id,
            deleted: "N"
        });
        Product.findByIdAndUpdate({
            _id: req.params.id
        }, productDetails, {
            new: true
        }).then(result => {
            res.status(200).json({
                Status: "completed",
                Title: "Update Product",
                message: "Product updated successfully",
                UpdatedRecord: result
            });
        }).catch(err => {
            console.log(err);
            return res.status(500).json({
                message: "Something went wrong.",
                Status: "error",
                Title: "Server Error",
            });
        })
    } else {
        res.status(401).json({
            message: "You dont have correct privilege to perform this operation",
            Status: "error",
            Title: "Access Denied",
        })
    }
}

//delete product from store -- only admin can delete product
// As for it's good practice always do not remove record completely from database
// so only updating record with deleted property to Yes
exports.deleteProduct = (req, res, next) => {
    if (req.userData.role == 'admin') {

        Product.findByIdAndUpdate({
            _id: req.params.id
        }, {
            deleted: 'Y'
        }, {
            new: true
        }).then(result => {
            if (!result) {
                return res.status(500).json({
                    message: "Something went wrong.",
                    Status: "error",
                    Title: "Server Error",
                });
            }
            if (result.deleted == 'Y') {
                return res.status(200).json({
                    Details: "Product deleted successfully.",
                    Status: "completed",
                    Title: "Product Delete",
                });
            } else {
                return res.status(200).json({
                    Details: "Product couldn't be deleted.",
                    Status: "error",
                    Title: "Product Delete",
                });
            }

        }).catch(error => {
            return res.status(500).json({
                message: "Something went wrong.",
                Status: "error",
                Title: "Server Error",
            });
        });
    } else {
        res.status(401).json({
            message: "You dont have correct privilege to perform this operation",
            Status: "error",
            Title: "Access Denied",
        })
    }
}