const mongoose = require('mongoose');
const userSchema = mongoose.Schema({
    invoice_number: {
        type: String,
    },
    employee_ID: {
        type: String
    },
    products_Saled: {
        type: Array,
    },
    any_discount: {
        type: String
    },
    vat_applied: {
        type: String
    },
    invoice_Total: {
        type: String
    },
    Trans_Date: {
        type: String,
    },
    Entered_Date: {
        type: Date,
        default: Date.now
    },
    deleted: {
        type: String
    }

}, {
    versionKey: false
})

module.exports = mongoose.model("Sales", userSchema, "sales");