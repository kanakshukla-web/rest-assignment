const mongoose = require('mongoose');
const userSchema = mongoose.Schema({
    email: {
        type: String,
        required: true,
        minlength: 5,
        maxlength: 50
    },

    password: {
        type: String,
        required: true,
        minlength: 5,
        maxlength: 1000
    },
    role: {
        type: String,
        enum: ['admin', 'manager'],
        default: 'manager'
    },
    created_At: {
        type: Date,
        default: Date.now
    }

}, {
    versionKey: false
})

module.exports = mongoose.model("User", userSchema, "users");