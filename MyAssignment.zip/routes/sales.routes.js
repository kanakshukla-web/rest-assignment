const express = require('express');
const router = express.Router();
const SalesController = require("../controllers/sales.controller");
const checkAuth = require("../middleware/check-auth");

router.post('/saveSales', checkAuth, SalesController.saveRecord);

module.exports = router;