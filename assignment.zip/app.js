var express = require('express');
var app = express();
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
mongoose.set('useCreateIndex', true);
mongoose.set('useFindAndModify', false);
const config = require("./config");

mongoose.connect(config.ConfigSettings.DatabaseUrl, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to database successfully.");
  })
  .catch((e) => {
    console.log("Connection failed!" + e.stack);
  });


app.use(bodyParser.json({
    limit: '50mb'
}));
app.use(bodyParser.urlencoded({
    limit: '50mb',
    extended: true
}));

app.set('trust proxy', true);
app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept, Authorization"
    );
    res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, PATCH, PUT, DELETE, OPTIONS"
    );
    next();

});

// user Routes
const userRoutes = require("../Assignment/routes/user.routes");
app.use("/api/user", userRoutes);

// product Routes
const productRoutes = require("../Assignment/routes/product.routes");
app.use("/api/products", productRoutes);

// sales Routes
const salesRoutes = require("../Assignment/routes/sales.routes");
app.use("/api/sales", salesRoutes);


module.exports = app;