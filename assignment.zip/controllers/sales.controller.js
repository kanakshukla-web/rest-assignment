const Sales = require("../models/sales.model");
const isEmpty = require('lodash.isempty');

// save invoice details to the database
exports.saveRecord = (req, res, next) => {

    if (isEmpty(req.body)) {
        return res.status(201).json({
            message: "Body content can't be empty",
            Status: "error",
            Title: "Missing Body",
        });
    }

    const invoiceDescription = new Sales({
        invoice_number: req.body.invoice_number,
        employee_ID: req.body.employee_ID,
        products_Saled: req.body.products_Saled,
        any_discount: req.body.any_discount,
        vat_applied: req.body.vat_applied,
        invoice_Total: req.userData.invoice_Total,
        Trans_Date: req.body.Trans_Date,
        deleted: "N"
    });

    invoiceDescription.save()
        .then(result => {
            console.log("Sales Record added successfully");

            res.status(200).json({
                Status: "completed",
                Title: "Add Record",
                message: "Sales record added successfully",
                RecordId: result._id
            });

        }).catch(err => {
            console.log(err);
            return res.status(500).json({
                message: "Something went wrong.",
                Status: "error",
                Title: "Server Error",
            });
        })
}