const express = require('express');
const router = express.Router();
const ProductController = require("../controllers/product.controller");
const checkAuth = require("../middleware/check-auth");

router.post('/addProduct', checkAuth, ProductController.addProduct);
router.get('/listProducts', checkAuth, ProductController.productsList);
router.get('/view/:id', checkAuth, ProductController.getProduct);
router.put('/update/:id', checkAuth, ProductController.updateProduct);
router.delete('/delete/:id', checkAuth, ProductController.deleteProduct);

module.exports = router;