const User = require("../models/user.model");
const isEmpty = require('lodash.isempty');
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const validator = require("email-validator");

// validate user
exports.validateUser = (req, res, next) => {

    if (isEmpty(req.body)) {
        return res.status(201).json({
            message: "Body content can't be empty",
            Status: "error",
            Title: "Missing Body",
        });
    }
    let fetchedUser;

    User.findOne({
        email: req.body.email
    }).then(dbResponse => {

        if (!dbResponse) {
            return res.status(200).json({
                message: "No account found for this email.",
                Status: "error",
                Title: "Unauthorized",
            });
        } else {
            // comparing request body Password with database saved Password.
            fetchedUser = dbResponse;
            return bcrypt.compare(req.body.password, dbResponse.password, function (err, isValid) {

                if (err) {
                    return res.status(500).json({
                        message: "Something went wrong.",
                        Status: "error",
                        Title: "Server Error",
                    });
                } else if (!isValid) {

                    return res.status(200).json({
                        message: "Incorrect password.",
                        Status: "error",
                        Title: "Invalid Credentials",
                    });

                } else {
                    if (fetchedUser != undefined) {
                        // creating JSON web token for user to secure other api's and to get info on basis of thier roles
                        // user have to send this token with Request Authorization Header to access other api's 
                        const token = jwt.sign({
                                email: fetchedUser.email,
                                role: fetchedUser.role,
                                userId: fetchedUser._id
                            },
                            process.env.JWT_KEY, {
                                expiresIn: "1d"
                            }
                        );
                        console.log("Successfully loggedIn");
                        res.status(200).json({
                            token: token,
                            expiresIn: 3600,
                            email: fetchedUser.email,
                            role: fetchedUser.role
                        });

                    } else {
                        //console.log("LogIn Failed!!");
                        return res.status(500).json({
                            message: "Something went wrong.",
                            Status: "error",
                            Title: "Server Error",
                        });
                    }
                }
            });
        }

    }).catch(err => {

        return res.status(500).json({
            message: "Something went wrong.",
            Status: "error",
            Title: "Server Error",
        });

    })
};

// register user
exports.signUp = (req, res, next) => {

    if (isEmpty(req.body)) {
        return res.status(201).json({
            message: "Body content can't be empty",
            Status: "error",
            Title: "Missing Body",
        });
    }

    if (validator.validate(req.body.email)) // check email is valid or not
    {
        User.find({ // check email already registered or not
            email: req.body.email
        }).then(dbResponse => {
            if (!dbResponse) {
                return res.status(500).json({
                    message: "Something went wrong.",
                    Status: "error",
                    Title: "Server Error",
                });
            } else {
                if (dbResponse.length == 0) { //email not exists

                    bcrypt.hash(req.body.password, 10).then(hash => {
                        const user = new User({
                            email: req.body.email,
                            role: req.body.role,
                            password: hash
                        });
                        user.save()
                            .then(result => {
                                console.log("User SignUp successfully");

                                res.status(200).json({
                                    Response: {
                                        Details: "User created Successfully.",
                                        result: result,
                                        Status: "completed",
                                        Title: "User SignUp",
                                    },
                                });
                            })
                            .catch(err => {
                                console.log(err);
                                return res.status(500).json({
                                    message: "Something went wrong.",
                                    Status: "error",
                                    Title: "Server Error",
                                });
                            });
                    });

                } else { // user already exists
                    return res.status(500).json({
                        message: "User already exists.",
                        Status: "error",
                        Title: "User SignUp",
                    });
                }
            }
        })
    } else {
        return res.status(500).json({
            message: "Please enter valid email.",
            Status: "error",
            Title: "Validation Error",
        });
    }
}