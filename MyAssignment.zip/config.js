const configSetting = {
  DatabaseUrl:"mongodb+srv://admin:admin@mycluster.ttv9s.mongodb.net/Test?retryWrites=true&w=majority",// local
  portNo: '8080',
  serverName: 'localhost',
  clientUrl: 'http://localhost:4200', // Local
  angularPort: '4200'
};

module.exports = {
  ConfigSettings: configSetting,
};