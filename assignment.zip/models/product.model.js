const mongoose = require('mongoose');
const userSchema = mongoose.Schema({
    name: {
        type: String,
    },
    category: {
        type: String
    },
    unit_price: {
        type: String,
    },
    avl_quantity: {
        type: String
    },
    image: {
        type: String
    },
    User_Id: {
        type: String
    },
    Entered_Date: {
        type: Date,
        default: Date.now
    },
    deleted: {
        type: String
    }

}, {
    versionKey: false
})

module.exports = mongoose.model("Product", userSchema, "products");